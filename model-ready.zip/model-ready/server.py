"""
Run python server.py in console (or just press the run button)

Then open:
    http://localhost:8000
"""
from discord_webhook import DiscordWebhook
import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from config import get_env
import joblib
import pandas as pd

from features import (
    ATTACK_THRESHOLD,
    DOS_LABEL,
    FEATURE_COLUMNS,
    NORMAL_LABEL,
    RECON_LABEL,
    create_normal_demo_features,
    create_reconnaissance_demo_features,
    create_suspicious_demo_features,
)

HOST = "localhost"
PORT = 8000

WEB_DIR = "web"
MODEL_PATH = os.path.join("model", "ddos_detector.joblib")


#   2 = DoS, 6 = Normal, 7 = Reconnaissance
CATEGORY_NAMES = {NORMAL_LABEL: "Normal", DOS_LABEL: "DoS", RECON_LABEL: "Reconnaissance"}


STATIC_FILES = {
    "/": ("index.html", "text/html"),
    "/index.html": ("index.html", "text/html"),
    "/style.css": ("style.css", "text/css"),
    "/script.js": ("script.js", "application/javascript"),
}

print("Loading trained model...")
model = joblib.load(MODEL_PATH)
NORMAL_CLASS_INDEX = list(model.classes_).index(NORMAL_LABEL)
print(f"Model loaded from {MODEL_PATH}")


def run_prediction(feature_values):
    """Pass a raw feature vector through the trained model and return
    (attack_probability, prediction_label, predicted_category)."""
    features_df = pd.DataFrame([feature_values], columns=FEATURE_COLUMNS)
    class_probabilities = model.predict_proba(features_df)[0]

    attack_probability = 1 - class_probabilities[NORMAL_CLASS_INDEX]
    predicted_label = model.classes_[class_probabilities.argmax()]
    predicted_category = CATEGORY_NAMES.get(predicted_label, str(predicted_label))

    if attack_probability >= ATTACK_THRESHOLD:
        prediction = "SUSPICIOUS"
    else:
        prediction = "NORMAL"

    return attack_probability, prediction, predicted_category


class DDoSDemoHandler(BaseHTTPRequestHandler):
    def _send_json(self, status_code, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_static(self, path):
        if path not in STATIC_FILES:
            self._send_json(404, {"error": "Not found"})
            return

        filename, content_type = STATIC_FILES[path]
        file_path = os.path.join(WEB_DIR, filename)

        try:
            with open(file_path, "rb") as f:
                body = f.read()
        except FileNotFoundError:
            self._send_json(404, {"error": "Not found"})
            return

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_prediction_endpoint(self, endpoint, feature_values):
        attack_probability, prediction, predicted_category = run_prediction(feature_values)

        if prediction == "SUSPICIOUS":
            status_code = 429
            allowed = False
            message = f"Suspicious activity detected, possible {predicted_category} activity"
        else:
            status_code = 200
            allowed = True
            message = "Request allowed"

        print("[REQUEST]")
        print(f"Endpoint: {endpoint}")
        print(f"Prediction: {prediction}")
        print(f"Predicted category: {predicted_category}")
        print(f"Attack probability: {attack_probability:.3f}")
        print(f"Action: {'ALLOWED' if allowed else 'BLOCKED'}")
        print(f"HTTP status: {status_code}\n", flush=True)
        # webhook notif
        if prediction == 'SUSPICIOUS':
            webhook = DiscordWebhook(url=get_env("webhookURL"),
                                  content=f"@everyone\nSuspicious Activity Detected.\nEndpoint: {endpoint}\nPredicted category: {predicted_category}\nCertainty: {attack_probability:.3f}\nAction Taken: {'ALLOWED' if allowed else 'BLOCKED'}")
            webhook.execute()

        self._send_json(
            status_code,
            {
                "allowed": allowed,
                "prediction": prediction,
                "attack_probability": round(float(attack_probability), 3),
                "http_status": status_code,
                "message": message,
            },
        )

    def do_GET(self):
        self._serve_static(self.path)

    def do_POST(self):
        if self.path == "/api/normal":
            self._handle_prediction_endpoint("/api/normal", create_normal_demo_features())
        elif self.path == "/api/simulate":
            self._handle_prediction_endpoint("/api/simulate", create_suspicious_demo_features())
        elif self.path == "/api/simulate-recon":
            self._handle_prediction_endpoint("/api/simulate-recon", create_reconnaissance_demo_features())
        else:
            self._send_json(404, {"error": "Not found"})

    def log_message(self, format, *args):
        # Keep default BaseHTTPRequestHandler access logging quiet;
        # our own [REQUEST] logs above are more useful for this demo.
        pass


def main():
    server = HTTPServer((HOST, PORT), DDoSDemoHandler)
    print(f"ML DDoS Detector demo running at http://{HOST}:{PORT}")
    print("Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.server_close()


if __name__ == "__main__":
    main()
