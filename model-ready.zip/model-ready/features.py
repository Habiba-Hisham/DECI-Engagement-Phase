
import json
import os
import random

STATS_PATH = os.path.join("model", "demo_stats.json")

with open(STATS_PATH) as f:
    _demo_stats = json.load(f)

FEATURE_COLUMNS = _demo_stats["feature_columns"]
NORMAL_LABEL = _demo_stats["normal_label"]
DOS_LABEL = _demo_stats["dos_label"]
RECON_LABEL = _demo_stats["recon_label"]
ATTACK_THRESHOLD = _demo_stats["attack_threshold"]

_NORMAL_ROWS = _demo_stats["normal_sample_rows"]
_DOS_ROWS = _demo_stats["dos_sample_rows"]
_RECON_ROWS = _demo_stats["recon_sample_rows"]

JITTER_LOW = 0.9
JITTER_HIGH = 1.1


def _jittered_row(sample_rows):
    row = random.choice(sample_rows)
    return [value * random.uniform(JITTER_LOW, JITTER_HIGH) for value in row]


def create_normal_demo_features():
    """Feature vector: a real Normal flow, jittered +/-10% per feature."""
    return _jittered_row(_NORMAL_ROWS)


def create_suspicious_demo_features():
    """Feature vector: a real DoS flow, jittered +/-10% per feature."""
    return _jittered_row(_DOS_ROWS)


def create_reconnaissance_demo_features():
    """Feature vector: a real Reconnaissance flow, jittered +/-10% per feature."""
    return _jittered_row(_RECON_ROWS)
