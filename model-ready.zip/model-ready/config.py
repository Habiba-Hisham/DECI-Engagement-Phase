import os
from dotenv import load_dotenv

load_dotenv()

def get_env(name):
    value = os.getenv(name)

    if value is None:
        raise ValueError(f"Missing environment variable: {name}")

    return value